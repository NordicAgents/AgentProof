export const meta = {
  name: 'realworld-validate-triage',
  description: 'Ground-truth validation of AST extraction + adversarial defect triage on mined GitHub workflows',
  phases: [
    { title: 'GroundTruth', detail: 'independent reference graph per sampled source file' },
    { title: 'Triage', detail: 'label each flagged defect: real / artifact / intentional' },
    { title: 'Verify', detail: 'adversarial re-check of triage labels' },
  ],
}

// args = {
//   groundTruth: [{slug, framework, source_path, graph_path}],
//   triage:      [{slug, framework, source_path, graph_path, defects:[{check_id, detail, witness}]}],
// }
const GT = [{"slug": "waqasniazi9__voice-agent__builder", "framework": "autogen", "source_path": "corpus/real_world/sources/waqasniazi9__voice-agent__builder.py", "graph_path": "corpus/real_world/graphs/waqasniazi9__voice-agent__builder.json"}, {"slug": "SPZts__AutoModel__model32", "framework": "autogen", "source_path": "corpus/real_world/sources/SPZts__AutoModel__model32.py", "graph_path": "corpus/real_world/graphs/SPZts__AutoModel__model32.json"}, {"slug": "MikhailMostWanted__Astra__test_group_chat_endpoint", "framework": "autogen", "source_path": "corpus/real_world/sources/MikhailMostWanted__Astra__test_group_chat_endpoint.py", "graph_path": "corpus/real_world/graphs/MikhailMostWanted__Astra__test_group_chat_endpoint.json"}, {"slug": "blueming333__aicraft-class-autogen__8_RunTeamStreamMCP", "framework": "autogen", "source_path": "corpus/real_world/sources/blueming333__aicraft-class-autogen__8_RunTeamStreamMCP.py", "graph_path": "corpus/real_world/graphs/blueming333__aicraft-class-autogen__8_RunTeamStreamMCP.json"}, {"slug": "microsoft__ACV__test_group_chat_endpoint", "framework": "autogen", "source_path": "corpus/real_world/sources/microsoft__ACV__test_group_chat_endpoint.py", "graph_path": "corpus/real_world/graphs/microsoft__ACV__test_group_chat_endpoint.json"}, {"slug": "nokia__mcp-redfish__agent", "framework": "autogen", "source_path": "corpus/real_world/sources/nokia__mcp-redfish__agent.py", "graph_path": "corpus/real_world/graphs/nokia__mcp-redfish__agent.json"}, {"slug": "Saimoguloju__AI-Agents__sample_agent", "framework": "autogen", "source_path": "corpus/real_world/sources/Saimoguloju__AI-Agents__sample_agent.py", "graph_path": "corpus/real_world/graphs/Saimoguloju__AI-Agents__sample_agent.json"}, {"slug": "MikhailMostWanted__Astra__app_team", "framework": "autogen", "source_path": "corpus/real_world/sources/MikhailMostWanted__Astra__app_team.py", "graph_path": "corpus/real_world/graphs/MikhailMostWanted__Astra__app_team.json"}, {"slug": "NanGePlus__AutoGenV04Test__CacheTeam", "framework": "autogen", "source_path": "corpus/real_world/sources/NanGePlus__AutoGenV04Test__CacheTeam.py", "graph_path": "corpus/real_world/graphs/NanGePlus__AutoGenV04Test__CacheTeam.json"}, {"slug": "blueming333__aicraft-class-autogen__PythonAstREPLTool", "framework": "autogen", "source_path": "corpus/real_world/sources/blueming333__aicraft-class-autogen__PythonAstREPLTool.py", "graph_path": "corpus/real_world/graphs/blueming333__aicraft-class-autogen__PythonAstREPLTool.json"}, {"slug": "blueming333__aicraft-class-autogen__2_RunTeam", "framework": "autogen", "source_path": "corpus/real_world/sources/blueming333__aicraft-class-autogen__2_RunTeam.py", "graph_path": "corpus/real_world/graphs/blueming333__aicraft-class-autogen__2_RunTeam.json"}, {"slug": "LightningGod7__prometheus__test_agent", "framework": "autogen", "source_path": "corpus/real_world/sources/LightningGod7__prometheus__test_agent.py", "graph_path": "corpus/real_world/graphs/LightningGod7__prometheus__test_agent.json"}, {"slug": "AkshatKumar12__AutoGen_Learning__teams", "framework": "autogen", "source_path": "corpus/real_world/sources/AkshatKumar12__AutoGen_Learning__teams.py", "graph_path": "corpus/real_world/graphs/AkshatKumar12__AutoGen_Learning__teams.json"}, {"slug": "MikhailMostWanted__Astra__test_team_manager", "framework": "autogen", "source_path": "corpus/real_world/sources/MikhailMostWanted__Astra__test_team_manager.py", "graph_path": "corpus/real_world/graphs/MikhailMostWanted__Astra__test_team_manager.json"}, {"slug": "ericjiang18__Agent-Q-Mix__test_agent", "framework": "autogen", "source_path": "corpus/real_world/sources/ericjiang18__Agent-Q-Mix__test_agent.py", "graph_path": "corpus/real_world/graphs/ericjiang18__Agent-Q-Mix__test_agent.json"}, {"slug": "project194-cognitivellm__cognitivellm__gwt_run_autogen_eval", "framework": "autogen", "source_path": "corpus/real_world/sources/project194-cognitivellm__cognitivellm__gwt_run_autogen_eval.py", "graph_path": "corpus/real_world/graphs/project194-cognitivellm__cognitivellm__gwt_run_autogen_eval.json"}, {"slug": "Damish-7__MOLYSIS__multi_agents", "framework": "autogen", "source_path": "corpus/real_world/sources/Damish-7__MOLYSIS__multi_agents.py", "graph_path": "corpus/real_world/graphs/Damish-7__MOLYSIS__multi_agents.json"}, {"slug": "microsoft__ACV__test_agent", "framework": "autogen", "source_path": "corpus/real_world/sources/microsoft__ACV__test_agent.py", "graph_path": "corpus/real_world/graphs/microsoft__ACV__test_agent.json"}, {"slug": "Sidreyas__The_Grand_AI_Repo__app_team_user_proxy", "framework": "autogen", "source_path": "corpus/real_world/sources/Sidreyas__The_Grand_AI_Repo__app_team_user_proxy.py", "graph_path": "corpus/real_world/graphs/Sidreyas__The_Grand_AI_Repo__app_team_user_proxy.json"}, {"slug": "AkshatKumar12__AutoGen_Learning__test", "framework": "autogen", "source_path": "corpus/real_world/sources/AkshatKumar12__AutoGen_Learning__test.py", "graph_path": "corpus/real_world/graphs/AkshatKumar12__AutoGen_Learning__test.json"}, {"slug": "blueming333__aicraft-class-autogen__GitHubOfficialMcpExample", "framework": "autogen", "source_path": "corpus/real_world/sources/blueming333__aicraft-class-autogen__GitHubOfficialMcpExample.py", "graph_path": "corpus/real_world/graphs/blueming333__aicraft-class-autogen__GitHubOfficialMcpExample.json"}, {"slug": "feixiao__ai__ex03", "framework": "autogen", "source_path": "corpus/real_world/sources/feixiao__ai__ex03.py", "graph_path": "corpus/real_world/graphs/feixiao__ai__ex03.json"}, {"slug": "SPZts__AutoModel__model22", "framework": "autogen", "source_path": "corpus/real_world/sources/SPZts__AutoModel__model22.py", "graph_path": "corpus/real_world/graphs/SPZts__AutoModel__model22.json"}, {"slug": "NavalGear__Manufacturing_Process_Plan__autogen_agents", "framework": "autogen", "source_path": "corpus/real_world/sources/NavalGear__Manufacturing_Process_Plan__autogen_agents.py", "graph_path": "corpus/real_world/graphs/NavalGear__Manufacturing_Process_Plan__autogen_agents.json"}, {"slug": "jkmaina__autogen_blueprint__03_model_based_selector", "framework": "autogen", "source_path": "corpus/real_world/sources/jkmaina__autogen_blueprint__03_model_based_selector.py", "graph_path": "corpus/real_world/graphs/jkmaina__autogen_blueprint__03_model_based_selector.json"}, {"slug": "Sidreyas__The_Grand_AI_Repo__builder", "framework": "autogen", "source_path": "corpus/real_world/sources/Sidreyas__The_Grand_AI_Repo__builder.py", "graph_path": "corpus/real_world/graphs/Sidreyas__The_Grand_AI_Repo__builder.json"}, {"slug": "Arhamirfan__Snake-Agents__snake_autogen", "framework": "autogen", "source_path": "corpus/real_world/sources/Arhamirfan__Snake-Agents__snake_autogen.py", "graph_path": "corpus/real_world/graphs/Arhamirfan__Snake-Agents__snake_autogen.json"}, {"slug": "Hsing-Tzu__AI-Aided-Systems__TRAgent", "framework": "autogen", "source_path": "corpus/real_world/sources/Hsing-Tzu__AI-Aided-Systems__TRAgent.py", "graph_path": "corpus/real_world/graphs/Hsing-Tzu__AI-Aided-Systems__TRAgent.json"}, {"slug": "NanGePlus__AutoGenV04Test__5_RunTeamStream", "framework": "autogen", "source_path": "corpus/real_world/sources/NanGePlus__AutoGenV04Test__5_RunTeamStream.py", "graph_path": "corpus/real_world/graphs/NanGePlus__AutoGenV04Test__5_RunTeamStream.json"}, {"slug": "Sidreyas__The_Grand_AI_Repo__test_society_of_mind_agent", "framework": "autogen", "source_path": "corpus/real_world/sources/Sidreyas__The_Grand_AI_Repo__test_society_of_mind_agent.py", "graph_path": "corpus/real_world/graphs/Sidreyas__The_Grand_AI_Repo__test_society_of_mind_agent.json"}, {"slug": "MikhailMostWanted__Astra__mcp_session_host_example", "framework": "autogen", "source_path": "corpus/real_world/sources/MikhailMostWanted__Astra__mcp_session_host_example.py", "graph_path": "corpus/real_world/graphs/MikhailMostWanted__Astra__mcp_session_host_example.json"}, {"slug": "arunacarunac__MultiAgentSamples__App", "framework": "autogen", "source_path": "corpus/real_world/sources/arunacarunac__MultiAgentSamples__App.py", "graph_path": "corpus/real_world/graphs/arunacarunac__MultiAgentSamples__App.json"}, {"slug": "microsoft__ACV__test_cache_agent", "framework": "autogen", "source_path": "corpus/real_world/sources/microsoft__ACV__test_cache_agent.py", "graph_path": "corpus/real_world/graphs/microsoft__ACV__test_cache_agent.json"}, {"slug": "Damish-7__MOLYSIS__health_agents", "framework": "autogen", "source_path": "corpus/real_world/sources/Damish-7__MOLYSIS__health_agents.py", "graph_path": "corpus/real_world/graphs/Damish-7__MOLYSIS__health_agents.json"}, {"slug": "Itzkuldeep__AgentE-com__main", "framework": "autogen", "source_path": "corpus/real_world/sources/Itzkuldeep__AgentE-com__main.py", "graph_path": "corpus/real_world/graphs/Itzkuldeep__AgentE-com__main.json"}, {"slug": "AIAnytime__agentic-context-engineering__curator", "framework": "adk", "source_path": "corpus/real_world/sources/AIAnytime__agentic-context-engineering__curator.py", "graph_path": "corpus/real_world/graphs/AIAnytime__agentic-context-engineering__curator.json"}, {"slug": "merdandt__SalesShortcut__potential_lead_finder_agent", "framework": "adk", "source_path": "corpus/real_world/sources/merdandt__SalesShortcut__potential_lead_finder_agent.py", "graph_path": "corpus/real_world/graphs/merdandt__SalesShortcut__potential_lead_finder_agent.json"}, {"slug": "volcengine__veadk-python__main", "framework": "adk", "source_path": "corpus/real_world/sources/volcengine__veadk-python__main.py", "graph_path": "corpus/real_world/graphs/volcengine__veadk-python__main.json"}, {"slug": "Zen7-Labs__Zen7-Payment-Agent__agent", "framework": "adk", "source_path": "corpus/real_world/sources/Zen7-Labs__Zen7-Payment-Agent__agent.py", "graph_path": "corpus/real_world/graphs/Zen7-Labs__Zen7-Payment-Agent__agent.json"}, {"slug": "AbhiShetye0703__Google-ADK__sequentialAgent", "framework": "adk", "source_path": "corpus/real_world/sources/AbhiShetye0703__Google-ADK__sequentialAgent.py", "graph_path": "corpus/real_world/graphs/AbhiShetye0703__Google-ADK__sequentialAgent.json"}, {"slug": "esk000__AIAgentsIntensive__LoopAgent", "framework": "adk", "source_path": "corpus/real_world/sources/esk000__AIAgentsIntensive__LoopAgent.py", "graph_path": "corpus/real_world/graphs/esk000__AIAgentsIntensive__LoopAgent.json"}, {"slug": "joansantoso__iox-adk__agent", "framework": "adk", "source_path": "corpus/real_world/sources/joansantoso__iox-adk__agent.py", "graph_path": "corpus/real_world/graphs/joansantoso__iox-adk__agent.json"}, {"slug": "sreekarrs__JobSearch-Agent__cv_writer", "framework": "adk", "source_path": "corpus/real_world/sources/sreekarrs__JobSearch-Agent__cv_writer.py", "graph_path": "corpus/real_world/graphs/sreekarrs__JobSearch-Agent__cv_writer.json"}, {"slug": "gabrielpreda__adk-sql-agent__agent", "framework": "adk", "source_path": "corpus/real_world/sources/gabrielpreda__adk-sql-agent__agent.py", "graph_path": "corpus/real_world/graphs/gabrielpreda__adk-sql-agent__agent.json"}, {"slug": "merdandt__SalesShortcut__websiter_creator_agent", "framework": "adk", "source_path": "corpus/real_world/sources/merdandt__SalesShortcut__websiter_creator_agent.py", "graph_path": "corpus/real_world/graphs/merdandt__SalesShortcut__websiter_creator_agent.json"}, {"slug": "merdandt__SalesShortcut__outreach_email_agent", "framework": "adk", "source_path": "corpus/real_world/sources/merdandt__SalesShortcut__outreach_email_agent.py", "graph_path": "corpus/real_world/graphs/merdandt__SalesShortcut__outreach_email_agent.json"}, {"slug": "NEU-Bio-Research-Team__tox-agent__orchestrator_agent", "framework": "adk", "source_path": "corpus/real_world/sources/NEU-Bio-Research-Team__tox-agent__orchestrator_agent.py", "graph_path": "corpus/real_world/graphs/NEU-Bio-Research-Team__tox-agent__orchestrator_agent.json"}, {"slug": "AbhiShetye0703__Google-ADK__parallelAgent", "framework": "adk", "source_path": "corpus/real_world/sources/AbhiShetye0703__Google-ADK__parallelAgent.py", "graph_path": "corpus/real_world/graphs/AbhiShetye0703__Google-ADK__parallelAgent.json"}, {"slug": "dream-horizon-org__pulse__agent", "framework": "adk", "source_path": "corpus/real_world/sources/dream-horizon-org__pulse__agent.py", "graph_path": "corpus/real_world/graphs/dream-horizon-org__pulse__agent.json"}, {"slug": "Astrodevil__ADK-Agent-Examples__agent", "framework": "adk", "source_path": "corpus/real_world/sources/Astrodevil__ADK-Agent-Examples__agent.py", "graph_path": "corpus/real_world/graphs/Astrodevil__ADK-Agent-Examples__agent.json"}, {"slug": "svpino__ml.school__agent", "framework": "adk", "source_path": "corpus/real_world/sources/svpino__ml.school__agent.py", "graph_path": "corpus/real_world/graphs/svpino__ml.school__agent.json"}, {"slug": "merdandt__SalesShortcut__email_agent", "framework": "adk", "source_path": "corpus/real_world/sources/merdandt__SalesShortcut__email_agent.py", "graph_path": "corpus/real_world/graphs/merdandt__SalesShortcut__email_agent.json"}, {"slug": "docker__compose-for-agents__agent", "framework": "adk", "source_path": "corpus/real_world/sources/docker__compose-for-agents__agent.py", "graph_path": "corpus/real_world/graphs/docker__compose-for-agents__agent.json"}, {"slug": "esk000__AIAgentsIntensive__parallelAgent", "framework": "adk", "source_path": "corpus/real_world/sources/esk000__AIAgentsIntensive__parallelAgent.py", "graph_path": "corpus/real_world/graphs/esk000__AIAgentsIntensive__parallelAgent.json"}, {"slug": "AsadAhmedSaiyed__Google-AI-Agent-Intensive-Course__LoopAgent", "framework": "adk", "source_path": "corpus/real_world/sources/AsadAhmedSaiyed__Google-AI-Agent-Intensive-Course__LoopAgent.py", "graph_path": "corpus/real_world/graphs/AsadAhmedSaiyed__Google-AI-Agent-Intensive-Course__LoopAgent.json"}, {"slug": "lordpython__multi-agent-video-system__agent", "framework": "adk", "source_path": "corpus/real_world/sources/lordpython__multi-agent-video-system__agent.py", "graph_path": "corpus/real_world/graphs/lordpython__multi-agent-video-system__agent.json"}, {"slug": "ed-donner__agents__sequential_agents", "framework": "adk", "source_path": "corpus/real_world/sources/ed-donner__agents__sequential_agents.py", "graph_path": "corpus/real_world/graphs/ed-donner__agents__sequential_agents.json"}, {"slug": "jpantsjoha__Agentic-Marketing-Campaign-Generator__marketing_orchestrator", "framework": "adk", "source_path": "corpus/real_world/sources/jpantsjoha__Agentic-Marketing-Campaign-Generator__marketing_orchestrator.py", "graph_path": "corpus/real_world/graphs/jpantsjoha__Agentic-Marketing-Campaign-Generator__marketing_orchestrator.json"}, {"slug": "ANONYMIZED__SELFREPO__test_extract_adk", "framework": "adk", "source_path": "corpus/real_world/sources/ANONYMIZED__SELFREPO__test_extract_adk.py", "graph_path": "corpus/real_world/graphs/ANONYMIZED__SELFREPO__test_extract_adk.json"}, {"slug": "brightertiger__google-adk-demo__agent", "framework": "adk", "source_path": "corpus/real_world/sources/brightertiger__google-adk-demo__agent.py", "graph_path": "corpus/real_world/graphs/brightertiger__google-adk-demo__agent.json"}]
const TR = [{"slug": "waqasniazi9__voice-agent__builder", "framework": "autogen", "source_path": "corpus/real_world/sources/waqasniazi9__voice-agent__builder.py", "graph_path": "corpus/real_world/graphs/waqasniazi9__voice-agent__builder.json", "defects": [{"check_id": "human_presence", "detail": "no human-in-the-loop node", "witness": ""}]}, {"slug": "SPZts__AutoModel__model32", "framework": "autogen", "source_path": "corpus/real_world/sources/SPZts__AutoModel__model32.py", "graph_path": "corpus/real_world/graphs/SPZts__AutoModel__model32.json", "defects": [{"check_id": "human_presence", "detail": "no human-in-the-loop node", "witness": ""}]}, {"slug": "MikhailMostWanted__Astra__test_group_chat_endpoint", "framework": "autogen", "source_path": "corpus/real_world/sources/MikhailMostWanted__Astra__test_group_chat_endpoint.py", "graph_path": "corpus/real_world/graphs/MikhailMostWanted__Astra__test_group_chat_endpoint.json", "defects": [{"check_id": "human_presence", "detail": "no human-in-the-loop node", "witness": ""}]}, {"slug": "blueming333__aicraft-class-autogen__8_RunTeamStreamMCP", "framework": "autogen", "source_path": "corpus/real_world/sources/blueming333__aicraft-class-autogen__8_RunTeamStreamMCP.py", "graph_path": "corpus/real_world/graphs/blueming333__aicraft-class-autogen__8_RunTeamStreamMCP.json", "defects": [{"check_id": "human_presence", "detail": "no human-in-the-loop node", "witness": ""}]}, {"slug": "microsoft__ACV__test_group_chat_endpoint", "framework": "autogen", "source_path": "corpus/real_world/sources/microsoft__ACV__test_group_chat_endpoint.py", "graph_path": "corpus/real_world/graphs/microsoft__ACV__test_group_chat_endpoint.json", "defects": [{"check_id": "human_presence", "detail": "no human-in-the-loop node", "witness": ""}]}, {"slug": "nokia__mcp-redfish__agent", "framework": "autogen", "source_path": "corpus/real_world/sources/nokia__mcp-redfish__agent.py", "graph_path": "corpus/real_world/graphs/nokia__mcp-redfish__agent.json", "defects": [{"check_id": "human_presence", "detail": "no human-in-the-loop node", "witness": ""}]}, {"slug": "Saimoguloju__AI-Agents__sample_agent", "framework": "autogen", "source_path": "corpus/real_world/sources/Saimoguloju__AI-Agents__sample_agent.py", "graph_path": "corpus/real_world/graphs/Saimoguloju__AI-Agents__sample_agent.json", "defects": [{"check_id": "human_presence", "detail": "no human-in-the-loop node", "witness": ""}]}, {"slug": "MikhailMostWanted__Astra__app_team", "framework": "autogen", "source_path": "corpus/real_world/sources/MikhailMostWanted__Astra__app_team.py", "graph_path": "corpus/real_world/graphs/MikhailMostWanted__Astra__app_team.json", "defects": [{"check_id": "human_presence", "detail": "no human-in-the-loop node", "witness": ""}]}, {"slug": "NanGePlus__AutoGenV04Test__CacheTeam", "framework": "autogen", "source_path": "corpus/real_world/sources/NanGePlus__AutoGenV04Test__CacheTeam.py", "graph_path": "corpus/real_world/graphs/NanGePlus__AutoGenV04Test__CacheTeam.json", "defects": [{"check_id": "human_presence", "detail": "no human-in-the-loop node", "witness": ""}]}, {"slug": "blueming333__aicraft-class-autogen__PythonAstREPLTool", "framework": "autogen", "source_path": "corpus/real_world/sources/blueming333__aicraft-class-autogen__PythonAstREPLTool.py", "graph_path": "corpus/real_world/graphs/blueming333__aicraft-class-autogen__PythonAstREPLTool.json", "defects": [{"check_id": "human_presence", "detail": "no human-in-the-loop node", "witness": ""}]}, {"slug": "blueming333__aicraft-class-autogen__2_RunTeam", "framework": "autogen", "source_path": "corpus/real_world/sources/blueming333__aicraft-class-autogen__2_RunTeam.py", "graph_path": "corpus/real_world/graphs/blueming333__aicraft-class-autogen__2_RunTeam.json", "defects": [{"check_id": "human_presence", "detail": "no human-in-the-loop node", "witness": ""}]}, {"slug": "LightningGod7__prometheus__test_agent", "framework": "autogen", "source_path": "corpus/real_world/sources/LightningGod7__prometheus__test_agent.py", "graph_path": "corpus/real_world/graphs/LightningGod7__prometheus__test_agent.json", "defects": [{"check_id": "human_presence", "detail": "no human-in-the-loop node", "witness": ""}]}, {"slug": "AkshatKumar12__AutoGen_Learning__teams", "framework": "autogen", "source_path": "corpus/real_world/sources/AkshatKumar12__AutoGen_Learning__teams.py", "graph_path": "corpus/real_world/graphs/AkshatKumar12__AutoGen_Learning__teams.json", "defects": [{"check_id": "human_presence", "detail": "no human-in-the-loop node", "witness": ""}]}, {"slug": "MikhailMostWanted__Astra__test_team_manager", "framework": "autogen", "source_path": "corpus/real_world/sources/MikhailMostWanted__Astra__test_team_manager.py", "graph_path": "corpus/real_world/graphs/MikhailMostWanted__Astra__test_team_manager.json", "defects": [{"check_id": "human_presence", "detail": "no human-in-the-loop node", "witness": ""}]}, {"slug": "ericjiang18__Agent-Q-Mix__test_agent", "framework": "autogen", "source_path": "corpus/real_world/sources/ericjiang18__Agent-Q-Mix__test_agent.py", "graph_path": "corpus/real_world/graphs/ericjiang18__Agent-Q-Mix__test_agent.json", "defects": [{"check_id": "human_presence", "detail": "no human-in-the-loop node", "witness": ""}]}, {"slug": "project194-cognitivellm__cognitivellm__gwt_run_autogen_eval", "framework": "autogen", "source_path": "corpus/real_world/sources/project194-cognitivellm__cognitivellm__gwt_run_autogen_eval.py", "graph_path": "corpus/real_world/graphs/project194-cognitivellm__cognitivellm__gwt_run_autogen_eval.json", "defects": [{"check_id": "human_presence", "detail": "no human-in-the-loop node", "witness": ""}]}, {"slug": "Damish-7__MOLYSIS__multi_agents", "framework": "autogen", "source_path": "corpus/real_world/sources/Damish-7__MOLYSIS__multi_agents.py", "graph_path": "corpus/real_world/graphs/Damish-7__MOLYSIS__multi_agents.json", "defects": [{"check_id": "human_presence", "detail": "no human-in-the-loop node", "witness": ""}]}, {"slug": "microsoft__ACV__test_agent", "framework": "autogen", "source_path": "corpus/real_world/sources/microsoft__ACV__test_agent.py", "graph_path": "corpus/real_world/graphs/microsoft__ACV__test_agent.json", "defects": [{"check_id": "human_presence", "detail": "no human-in-the-loop node", "witness": ""}]}, {"slug": "Sidreyas__The_Grand_AI_Repo__app_team_user_proxy", "framework": "autogen", "source_path": "corpus/real_world/sources/Sidreyas__The_Grand_AI_Repo__app_team_user_proxy.py", "graph_path": "corpus/real_world/graphs/Sidreyas__The_Grand_AI_Repo__app_team_user_proxy.json", "defects": []}, {"slug": "AkshatKumar12__AutoGen_Learning__test", "framework": "autogen", "source_path": "corpus/real_world/sources/AkshatKumar12__AutoGen_Learning__test.py", "graph_path": "corpus/real_world/graphs/AkshatKumar12__AutoGen_Learning__test.json", "defects": [{"check_id": "human_presence", "detail": "no human-in-the-loop node", "witness": ""}]}, {"slug": "blueming333__aicraft-class-autogen__GitHubOfficialMcpExample", "framework": "autogen", "source_path": "corpus/real_world/sources/blueming333__aicraft-class-autogen__GitHubOfficialMcpExample.py", "graph_path": "corpus/real_world/graphs/blueming333__aicraft-class-autogen__GitHubOfficialMcpExample.json", "defects": [{"check_id": "human_presence", "detail": "no human-in-the-loop node", "witness": ""}]}, {"slug": "feixiao__ai__ex03", "framework": "autogen", "source_path": "corpus/real_world/sources/feixiao__ai__ex03.py", "graph_path": "corpus/real_world/graphs/feixiao__ai__ex03.json", "defects": [{"check_id": "human_presence", "detail": "no human-in-the-loop node", "witness": ""}]}, {"slug": "SPZts__AutoModel__model22", "framework": "autogen", "source_path": "corpus/real_world/sources/SPZts__AutoModel__model22.py", "graph_path": "corpus/real_world/graphs/SPZts__AutoModel__model22.json", "defects": [{"check_id": "human_presence", "detail": "no human-in-the-loop node", "witness": ""}]}, {"slug": "NavalGear__Manufacturing_Process_Plan__autogen_agents", "framework": "autogen", "source_path": "corpus/real_world/sources/NavalGear__Manufacturing_Process_Plan__autogen_agents.py", "graph_path": "corpus/real_world/graphs/NavalGear__Manufacturing_Process_Plan__autogen_agents.json", "defects": []}, {"slug": "jkmaina__autogen_blueprint__03_model_based_selector", "framework": "autogen", "source_path": "corpus/real_world/sources/jkmaina__autogen_blueprint__03_model_based_selector.py", "graph_path": "corpus/real_world/graphs/jkmaina__autogen_blueprint__03_model_based_selector.json", "defects": [{"check_id": "human_presence", "detail": "no human-in-the-loop node", "witness": ""}]}, {"slug": "Sidreyas__The_Grand_AI_Repo__builder", "framework": "autogen", "source_path": "corpus/real_world/sources/Sidreyas__The_Grand_AI_Repo__builder.py", "graph_path": "corpus/real_world/graphs/Sidreyas__The_Grand_AI_Repo__builder.json", "defects": [{"check_id": "human_presence", "detail": "no human-in-the-loop node", "witness": ""}]}, {"slug": "Arhamirfan__Snake-Agents__snake_autogen", "framework": "autogen", "source_path": "corpus/real_world/sources/Arhamirfan__Snake-Agents__snake_autogen.py", "graph_path": "corpus/real_world/graphs/Arhamirfan__Snake-Agents__snake_autogen.json", "defects": []}, {"slug": "Hsing-Tzu__AI-Aided-Systems__TRAgent", "framework": "autogen", "source_path": "corpus/real_world/sources/Hsing-Tzu__AI-Aided-Systems__TRAgent.py", "graph_path": "corpus/real_world/graphs/Hsing-Tzu__AI-Aided-Systems__TRAgent.json", "defects": []}, {"slug": "NanGePlus__AutoGenV04Test__5_RunTeamStream", "framework": "autogen", "source_path": "corpus/real_world/sources/NanGePlus__AutoGenV04Test__5_RunTeamStream.py", "graph_path": "corpus/real_world/graphs/NanGePlus__AutoGenV04Test__5_RunTeamStream.json", "defects": [{"check_id": "human_presence", "detail": "no human-in-the-loop node", "witness": ""}]}, {"slug": "Sidreyas__The_Grand_AI_Repo__test_society_of_mind_agent", "framework": "autogen", "source_path": "corpus/real_world/sources/Sidreyas__The_Grand_AI_Repo__test_society_of_mind_agent.py", "graph_path": "corpus/real_world/graphs/Sidreyas__The_Grand_AI_Repo__test_society_of_mind_agent.json", "defects": [{"check_id": "human_presence", "detail": "no human-in-the-loop node", "witness": ""}]}, {"slug": "MikhailMostWanted__Astra__mcp_session_host_example", "framework": "autogen", "source_path": "corpus/real_world/sources/MikhailMostWanted__Astra__mcp_session_host_example.py", "graph_path": "corpus/real_world/graphs/MikhailMostWanted__Astra__mcp_session_host_example.json", "defects": [{"check_id": "human_presence", "detail": "no human-in-the-loop node", "witness": ""}]}, {"slug": "arunacarunac__MultiAgentSamples__App", "framework": "autogen", "source_path": "corpus/real_world/sources/arunacarunac__MultiAgentSamples__App.py", "graph_path": "corpus/real_world/graphs/arunacarunac__MultiAgentSamples__App.json", "defects": [{"check_id": "human_presence", "detail": "no human-in-the-loop node", "witness": ""}]}, {"slug": "microsoft__ACV__test_cache_agent", "framework": "autogen", "source_path": "corpus/real_world/sources/microsoft__ACV__test_cache_agent.py", "graph_path": "corpus/real_world/graphs/microsoft__ACV__test_cache_agent.json", "defects": []}, {"slug": "Damish-7__MOLYSIS__health_agents", "framework": "autogen", "source_path": "corpus/real_world/sources/Damish-7__MOLYSIS__health_agents.py", "graph_path": "corpus/real_world/graphs/Damish-7__MOLYSIS__health_agents.json", "defects": [{"check_id": "human_presence", "detail": "no human-in-the-loop node", "witness": ""}]}, {"slug": "Itzkuldeep__AgentE-com__main", "framework": "autogen", "source_path": "corpus/real_world/sources/Itzkuldeep__AgentE-com__main.py", "graph_path": "corpus/real_world/graphs/Itzkuldeep__AgentE-com__main.json", "defects": []}, {"slug": "AIAnytime__agentic-context-engineering__curator", "framework": "adk", "source_path": "corpus/real_world/sources/AIAnytime__agentic-context-engineering__curator.py", "graph_path": "corpus/real_world/graphs/AIAnytime__agentic-context-engineering__curator.json", "defects": [{"check_id": "human_presence", "detail": "no human-in-the-loop node", "witness": ""}]}, {"slug": "merdandt__SalesShortcut__potential_lead_finder_agent", "framework": "adk", "source_path": "corpus/real_world/sources/merdandt__SalesShortcut__potential_lead_finder_agent.py", "graph_path": "corpus/real_world/graphs/merdandt__SalesShortcut__potential_lead_finder_agent.json", "defects": [{"check_id": "human_presence", "detail": "no human-in-the-loop node", "witness": ""}]}, {"slug": "volcengine__veadk-python__main", "framework": "adk", "source_path": "corpus/real_world/sources/volcengine__veadk-python__main.py", "graph_path": "corpus/real_world/graphs/volcengine__veadk-python__main.json", "defects": [{"check_id": "human_presence", "detail": "no human-in-the-loop node", "witness": ""}]}, {"slug": "Zen7-Labs__Zen7-Payment-Agent__agent", "framework": "adk", "source_path": "corpus/real_world/sources/Zen7-Labs__Zen7-Payment-Agent__agent.py", "graph_path": "corpus/real_world/graphs/Zen7-Labs__Zen7-Payment-Agent__agent.json", "defects": [{"check_id": "human_presence", "detail": "no human-in-the-loop node", "witness": ""}]}, {"slug": "AbhiShetye0703__Google-ADK__sequentialAgent", "framework": "adk", "source_path": "corpus/real_world/sources/AbhiShetye0703__Google-ADK__sequentialAgent.py", "graph_path": "corpus/real_world/graphs/AbhiShetye0703__Google-ADK__sequentialAgent.json", "defects": [{"check_id": "human_presence", "detail": "no human-in-the-loop node", "witness": ""}]}, {"slug": "esk000__AIAgentsIntensive__LoopAgent", "framework": "adk", "source_path": "corpus/real_world/sources/esk000__AIAgentsIntensive__LoopAgent.py", "graph_path": "corpus/real_world/graphs/esk000__AIAgentsIntensive__LoopAgent.json", "defects": [{"check_id": "human_presence", "detail": "no human-in-the-loop node", "witness": ""}]}, {"slug": "joansantoso__iox-adk__agent", "framework": "adk", "source_path": "corpus/real_world/sources/joansantoso__iox-adk__agent.py", "graph_path": "corpus/real_world/graphs/joansantoso__iox-adk__agent.json", "defects": [{"check_id": "human_presence", "detail": "no human-in-the-loop node", "witness": ""}]}, {"slug": "sreekarrs__JobSearch-Agent__cv_writer", "framework": "adk", "source_path": "corpus/real_world/sources/sreekarrs__JobSearch-Agent__cv_writer.py", "graph_path": "corpus/real_world/graphs/sreekarrs__JobSearch-Agent__cv_writer.json", "defects": [{"check_id": "human_presence", "detail": "no human-in-the-loop node", "witness": ""}]}, {"slug": "gabrielpreda__adk-sql-agent__agent", "framework": "adk", "source_path": "corpus/real_world/sources/gabrielpreda__adk-sql-agent__agent.py", "graph_path": "corpus/real_world/graphs/gabrielpreda__adk-sql-agent__agent.json", "defects": [{"check_id": "human_presence", "detail": "no human-in-the-loop node", "witness": ""}]}, {"slug": "merdandt__SalesShortcut__websiter_creator_agent", "framework": "adk", "source_path": "corpus/real_world/sources/merdandt__SalesShortcut__websiter_creator_agent.py", "graph_path": "corpus/real_world/graphs/merdandt__SalesShortcut__websiter_creator_agent.json", "defects": [{"check_id": "human_presence", "detail": "no human-in-the-loop node", "witness": ""}]}, {"slug": "merdandt__SalesShortcut__outreach_email_agent", "framework": "adk", "source_path": "corpus/real_world/sources/merdandt__SalesShortcut__outreach_email_agent.py", "graph_path": "corpus/real_world/graphs/merdandt__SalesShortcut__outreach_email_agent.json", "defects": [{"check_id": "human_presence", "detail": "no human-in-the-loop node", "witness": ""}]}, {"slug": "NEU-Bio-Research-Team__tox-agent__orchestrator_agent", "framework": "adk", "source_path": "corpus/real_world/sources/NEU-Bio-Research-Team__tox-agent__orchestrator_agent.py", "graph_path": "corpus/real_world/graphs/NEU-Bio-Research-Team__tox-agent__orchestrator_agent.json", "defects": [{"check_id": "human_presence", "detail": "no human-in-the-loop node", "witness": ""}]}, {"slug": "AbhiShetye0703__Google-ADK__parallelAgent", "framework": "adk", "source_path": "corpus/real_world/sources/AbhiShetye0703__Google-ADK__parallelAgent.py", "graph_path": "corpus/real_world/graphs/AbhiShetye0703__Google-ADK__parallelAgent.json", "defects": [{"check_id": "human_presence", "detail": "no human-in-the-loop node", "witness": ""}]}, {"slug": "dream-horizon-org__pulse__agent", "framework": "adk", "source_path": "corpus/real_world/sources/dream-horizon-org__pulse__agent.py", "graph_path": "corpus/real_world/graphs/dream-horizon-org__pulse__agent.json", "defects": [{"check_id": "human_presence", "detail": "no human-in-the-loop node", "witness": ""}]}, {"slug": "Astrodevil__ADK-Agent-Examples__agent", "framework": "adk", "source_path": "corpus/real_world/sources/Astrodevil__ADK-Agent-Examples__agent.py", "graph_path": "corpus/real_world/graphs/Astrodevil__ADK-Agent-Examples__agent.json", "defects": [{"check_id": "human_presence", "detail": "no human-in-the-loop node", "witness": ""}]}, {"slug": "svpino__ml.school__agent", "framework": "adk", "source_path": "corpus/real_world/sources/svpino__ml.school__agent.py", "graph_path": "corpus/real_world/graphs/svpino__ml.school__agent.json", "defects": [{"check_id": "human_presence", "detail": "no human-in-the-loop node", "witness": ""}]}, {"slug": "merdandt__SalesShortcut__email_agent", "framework": "adk", "source_path": "corpus/real_world/sources/merdandt__SalesShortcut__email_agent.py", "graph_path": "corpus/real_world/graphs/merdandt__SalesShortcut__email_agent.json", "defects": [{"check_id": "human_presence", "detail": "no human-in-the-loop node", "witness": ""}]}, {"slug": "docker__compose-for-agents__agent", "framework": "adk", "source_path": "corpus/real_world/sources/docker__compose-for-agents__agent.py", "graph_path": "corpus/real_world/graphs/docker__compose-for-agents__agent.json", "defects": [{"check_id": "human_presence", "detail": "no human-in-the-loop node", "witness": ""}]}, {"slug": "esk000__AIAgentsIntensive__parallelAgent", "framework": "adk", "source_path": "corpus/real_world/sources/esk000__AIAgentsIntensive__parallelAgent.py", "graph_path": "corpus/real_world/graphs/esk000__AIAgentsIntensive__parallelAgent.json", "defects": [{"check_id": "human_presence", "detail": "no human-in-the-loop node", "witness": ""}]}, {"slug": "AsadAhmedSaiyed__Google-AI-Agent-Intensive-Course__LoopAgent", "framework": "adk", "source_path": "corpus/real_world/sources/AsadAhmedSaiyed__Google-AI-Agent-Intensive-Course__LoopAgent.py", "graph_path": "corpus/real_world/graphs/AsadAhmedSaiyed__Google-AI-Agent-Intensive-Course__LoopAgent.json", "defects": [{"check_id": "human_presence", "detail": "no human-in-the-loop node", "witness": ""}]}, {"slug": "lordpython__multi-agent-video-system__agent", "framework": "adk", "source_path": "corpus/real_world/sources/lordpython__multi-agent-video-system__agent.py", "graph_path": "corpus/real_world/graphs/lordpython__multi-agent-video-system__agent.json", "defects": [{"check_id": "human_presence", "detail": "no human-in-the-loop node", "witness": ""}]}, {"slug": "ed-donner__agents__sequential_agents", "framework": "adk", "source_path": "corpus/real_world/sources/ed-donner__agents__sequential_agents.py", "graph_path": "corpus/real_world/graphs/ed-donner__agents__sequential_agents.json", "defects": [{"check_id": "human_presence", "detail": "no human-in-the-loop node", "witness": ""}]}, {"slug": "jpantsjoha__Agentic-Marketing-Campaign-Generator__marketing_orchestrator", "framework": "adk", "source_path": "corpus/real_world/sources/jpantsjoha__Agentic-Marketing-Campaign-Generator__marketing_orchestrator.py", "graph_path": "corpus/real_world/graphs/jpantsjoha__Agentic-Marketing-Campaign-Generator__marketing_orchestrator.json", "defects": [{"check_id": "human_presence", "detail": "no human-in-the-loop node", "witness": ""}]}, {"slug": "ANONYMIZED__SELFREPO__test_extract_adk", "framework": "adk", "source_path": "corpus/real_world/sources/ANONYMIZED__SELFREPO__test_extract_adk.py", "graph_path": "corpus/real_world/graphs/ANONYMIZED__SELFREPO__test_extract_adk.json", "defects": [{"check_id": "human_presence", "detail": "no human-in-the-loop node", "witness": ""}]}, {"slug": "brightertiger__google-adk-demo__agent", "framework": "adk", "source_path": "corpus/real_world/sources/brightertiger__google-adk-demo__agent.py", "graph_path": "corpus/real_world/graphs/brightertiger__google-adk-demo__agent.json", "defects": [{"check_id": "human_presence", "detail": "no human-in-the-loop node", "witness": ""}]}]

const ID_CONVENTIONS = `
NODE-ID CONVENTIONS (must match these so the reference aligns with the automatic extractor):
- LangGraph: the node id is EXACTLY the first string argument to add_node("...").
  Entry sentinel id = "__start__", exit sentinel id = "__end__". END -> "__end__", START -> "__start__".
- CrewAI: one node per Task(...). id = the task's description string, first 50 chars, lowercased,
  spaces replaced with underscores. Tasks run sequentially in Crew(tasks=[...]) order unless process= says otherwise.
- AutoGen: one node per participant/agent. id = the agent's Python variable name as passed to the group chat.
  RoundRobin adds a loop edge from the last agent back to the first.
- ADK: one node per sub_agent. id = the sub_agent's name string (or variable). SequentialAgent chains them;
  ParallelAgent fans __start__ out to each and each back to __end__.
Always include the "__start__" (kind entry) and "__end__" (kind exit) sentinels.`

const KIND_RULES = `
NODE KINDS (pick exactly one per node): entry, exit, tool, llm, router, human, subgraph, passthrough.
- tool: the node's job is to call an external tool / API / function (or the framework binds tools to it).
- llm: an inference / agent-reasoning / generation step with no external side-effecting tool.
- router: a node whose outgoing edges are conditional branches (dispatch/classify-and-route).
- human: a human-in-the-loop step: approval gate, manual review, input()/interrupt, "ask the user".
- subgraph: a node that embeds a nested workflow graph.
EDGE KINDS: direct, conditional (from routers / add_conditional_edges), parallel, loop (cycles/round-robin).`

const GT_SCHEMA = {
  type: 'object',
  required: ['slug', 'nodes', 'edges', 'entry_id', 'exit_ids', 'notes'],
  properties: {
    slug: { type: 'string' },
    framework: { type: 'string' },
    entry_id: { type: 'string' },
    exit_ids: { type: 'array', items: { type: 'string' } },
    nodes: {
      type: 'array',
      items: {
        type: 'object',
        required: ['id', 'kind'],
        properties: {
          id: { type: 'string' },
          kind: { enum: ['entry', 'exit', 'tool', 'llm', 'router', 'human', 'subgraph', 'passthrough'] },
          label: { type: 'string' },
          tools: { type: 'array', items: { type: 'string' } },
        },
      },
    },
    edges: {
      type: 'array',
      items: {
        type: 'object',
        required: ['source', 'target'],
        properties: {
          source: { type: 'string' },
          target: { type: 'string' },
          kind: { enum: ['direct', 'conditional', 'parallel', 'loop'] },
        },
      },
    },
    confidence: { enum: ['high', 'medium', 'low'] },
    notes: { type: 'string' },
  },
}

const TRIAGE_SCHEMA = {
  type: 'object',
  required: ['slug', 'labels'],
  properties: {
    slug: { type: 'string' },
    labels: {
      type: 'array',
      items: {
        type: 'object',
        required: ['check_id', 'label', 'justification'],
        properties: {
          check_id: { type: 'string' },
          detail: { type: 'string' },
          label: { enum: ['real_defect', 'extraction_artifact', 'intentional', 'arguable'] },
          confidence: { enum: ['high', 'medium', 'low'] },
          justification: { type: 'string' },
        },
      },
    },
  },
}

const VERIFY_SCHEMA = {
  type: 'object',
  required: ['slug', 'reviews'],
  properties: {
    slug: { type: 'string' },
    reviews: {
      type: 'array',
      items: {
        type: 'object',
        required: ['check_id', 'agree', 'final_label'],
        properties: {
          check_id: { type: 'string' },
          agree: { type: 'boolean' },
          final_label: { enum: ['real_defect', 'extraction_artifact', 'intentional', 'arguable'] },
          reason: { type: 'string' },
        },
      },
    },
  },
}

function gtPrompt(item) {
  return `You are validating an automatic workflow-graph extractor by building an INDEPENDENT ground-truth graph.

Read the real ${item.framework} source file at:
  ${item.source_path}

Reconstruct the TRUE agent workflow graph purely from the source (do NOT look at the extractor output).
${ID_CONVENTIONS}
${KIND_RULES}

Rules:
- Only include nodes/edges that genuinely exist in the source. If the workflow is built dynamically
  (nodes added in loops/comprehensions, edges from variables), infer the concrete graph if determinable;
  if a portion is genuinely undeterminable from static source, omit it and say so in notes.
- Use kind "tool" only when the node actually invokes an external tool/API/function or has tools bound.
- Set confidence low if the file is a partial snippet, a library wrapper, or not really a workflow definition.
- Return slug="${item.slug}", framework="${item.framework}", and put any caveats in notes.`
}

function triagePrompt(item) {
  const defectList = item.defects
    .map((d, i) => `  ${i + 1}. check_id=${d.check_id} :: ${d.detail}${d.witness ? ` :: witness=${d.witness}` : ''}`)
    .join('\n')
  return `A static verifier flagged defects in a workflow graph AUTOMATICALLY EXTRACTED from real GitHub source.
Your job: for EACH flagged defect decide whether it is a genuine problem in the real workflow, or merely an
artifact of imperfect extraction, or an intentional design choice.

Real ${item.framework} source file:  ${item.source_path}
Extracted graph JSON:                ${item.graph_path}

Flagged defects:
${defectList}

Read BOTH files. For each defect assign one label:
- real_defect: the actual source workflow really has this problem (e.g., a node truly has no outgoing
  transition, an exit is truly unreachable, a router truly uses non-conditional edges, a sensitive path
  truly bypasses human review). A developer would want to fix it.
- extraction_artifact: the defect exists ONLY because the AST extractor missed edges/nodes or misclassified
  a node. The real workflow is fine. (This is common when edges are built from variables, loops, END
  sentinels, or conditional maps the static extractor cannot resolve.)
- intentional: the pattern is a deliberate design choice (e.g., a terminal node that intentionally halts,
  or a genuinely low-risk workflow that legitimately needs no human gate).
- arguable: genuinely unclear from the source.

Ground every label in specific evidence from the source (quote the relevant lines). Return slug="${item.slug}".`
}

function verifyPrompt(item, primary) {
  return `Adversarially re-check another reviewer's triage of extraction-flagged defects. Try to OVERTURN each
label; only agree if the evidence in the source truly supports it.

Real ${item.framework} source:  ${item.source_path}
Extracted graph JSON:           ${item.graph_path}

Primary reviewer's labels:
${primary.labels.map((l) => `  - ${l.check_id}: ${l.label} (${l.confidence || 'n/a'}) -- ${l.justification}`).join('\n')}

Read the source yourself. For each check_id, state whether you agree; if not, give the correct final_label
and why. If primary and your view disagree and neither is clearly right, final_label = "arguable".
Return slug="${item.slug}".`
}

// ---- Phase 1: ground-truth reference graphs (independent, single careful agent each) ----
phase('GroundTruth')
log(`Building ${GT.length} ground-truth reference graphs`)
const groundTruth = await parallel(
  GT.map((item) => () =>
    agent(gtPrompt(item), {
      label: `gt:${item.slug}`,
      phase: 'GroundTruth',
      agentType: 'general-purpose',
      schema: GT_SCHEMA,
    }).then((g) => (g ? { ...g, framework: g.framework || item.framework } : null))
  )
)

// ---- Phase 2+3: triage each defective workflow, then adversarially verify ----
phase('Triage')
log(`Triaging ${TR.length} defective workflows (primary label -> adversarial verify)`)
const triaged = await pipeline(
  TR,
  (item) =>
    agent(triagePrompt(item), {
      label: `triage:${item.slug}`,
      phase: 'Triage',
      agentType: 'general-purpose',
      schema: TRIAGE_SCHEMA,
    }).then((primary) => ({ item, primary })),
  ({ item, primary }) => {
    if (!primary) return null
    return agent(verifyPrompt(item, primary), {
      label: `verify:${item.slug}`,
      phase: 'Verify',
      agentType: 'general-purpose',
      schema: VERIFY_SCHEMA,
    }).then((verdict) => {
      // reconcile: keep primary label when verifier agrees; else use verifier final_label
      const vmap = {}
      for (const r of (verdict && verdict.reviews) || []) vmap[r.check_id] = r
      const reconciled = primary.labels.map((l) => {
        const v = vmap[l.check_id]
        if (!v) return { ...l, final_label: l.label, verified: false }
        return {
          ...l,
          final_label: v.agree ? l.label : v.final_label,
          verified: true,
          agreed: !!v.agree,
          verifier_reason: v.reason || '',
        }
      })
      return { slug: item.slug, framework: item.framework, labels: reconciled }
    })
  }
)

return {
  groundTruth: groundTruth.filter(Boolean),
  triage: triaged.filter(Boolean),
  counts: { gt: GT.length, triage: TR.length },
}
