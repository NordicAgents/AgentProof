# Anonymized Review Artifact

Code-and-data artifact for the anonymous submission:

> **Before Verifying Agent Workflows: Auditing Extraction Fidelity and Policy
> Applicability**

The artifact contains the analyzer, tests, derived corpora, reconstructed
reference graphs, LLM-assisted labels and justifications, audit scripts, and
the locked independent-human-validation protocol. It runs offline except for
the optional pinned re-mining step.

## Quick start

From the extracted `workflow_verifier/` directory:

```bash
python -m venv .venv
. .venv/bin/activate
pip install -e ".[dev]"
python -m pytest tests/ -q
PYTHONPATH=src python scripts/pruning_experiment.py
PYTHONPATH=src python scripts/fp_fn_decomposition.py
python scripts/human_agreement.py
```

Python 3.10 or newer is required, as declared by `pyproject.toml`. In the full
source checkout the submitted revision passes 423 tests with one skipped test.
The anonymous archive passes 421 tests with three skipped tests: two prospective
sample-regeneration checks need the third-party source snapshots that the
archive deliberately does not redistribute. The project has no core runtime
dependency; `pytest` is needed for the test suite.

With `uv`, the equivalent one-line test command is:

```bash
uv run --frozen --extra dev python -m pytest tests/ -q
```

## Key paper claims and artifacts

| Claim | Reproduction command | Output |
|---|---|---|
| Current structural/HGP-1 estimands and audit summaries | `python scripts/human_gate_audit.py && python scripts/reviewer_analyses.py` | `corpus/real_world/human_gate_audit.json`, `reviewer_analyses.json` |
| Matched extraction-fidelity comparison | `python scripts/matched_fidelity.py` | `corpus/real_world/matched_fidelity.json` |
| Finding attribution and reverse audit of misses | `PYTHONPATH=src python scripts/fp_fn_decomposition.py` | `corpus/real_world/fp_fn_decomposition.json` |
| HGP-1 source-level policy audit | `python scripts/human_gate_audit.py` | `corpus/real_world/human_gate_audit.json` |
| Controlled graph-product mechanism check | `PYTHONPATH=src python scripts/pruning_experiment.py` | `corpus/real_world/pruning_experiment.json` |
| Independent human agreement | `python scripts/human_agreement.py` | `corpus/annotations/human_agreement.json` |
| Frozen prospective replacement sample | `python scripts/make_prospective_validation_sample.py --check` | `corpus/annotations/prospective_validation_manifest.json` |
| Cross-artifact headline consistency | `python scripts/validate_submission_claims.py` | exits nonzero on any mismatch |

`scripts/reproduce_all.sh` runs HGP-1 before the reviewer summaries and then
checks that no current output has reverted to the withdrawn 3/119 two-check
union or the pre-exclusion 187-flag dataset.

The monitor checker returns `safe` only when the caller explicitly asserts that
the authored abstraction covers every relevant event. Exact source provenance
qualifies witnesses but does not establish event coverage. Mined graphs in this
study therefore receive no `safe` verdict.

## Human-validation status

The two-annotator protocol, locked samples, independent worksheets, and scoring
script are under `corpus/annotations/`. At submission-build time the worksheets
are blank, so the paper identifies independent human validation as pending.
After both annotators complete the worksheets, run:

```bash
python scripts/human_agreement.py
```

This produces human--human agreement, human--LLM agreement, graph-reconstruction
agreement, repository-cluster bootstrap intervals, and per-item scores.

The artifact also includes a frozen, outcome-blind prospective replacement for
the historical nonrandom 119-file set: 96 files selected by a seeded two-stage
design, with exact inclusion probabilities and 32 files marked for independent
dual-human reconstruction. See `PROSPECTIVE_VALIDATION_PROTOCOL.md`. It contains
no prospective outcomes at submission time and is not used to inflate the
current paper's evidence.

## Anonymization and data handling

- Author names, organization identifiers, author-repository slugs, and local
  absolute paths are scrubbed in the archive.
- Third-party GitHub provenance is retained because it identifies the public
  data being audited, not the submitting authors.
- Third-party source snapshots are not redistributed. Derived graph
  abstractions, pinned repository/commit/path provenance, and optional
  `scripts/remine_pinned.py` are provided instead.
- The authors' own eight test-fixture files are pseudonymized with the
  `ANONYMIZED__SELFREPO` prefix and excluded from every reported denominator.

## Main contents

- `src/workflow_verifier/`: graph model, four framework extractors, checks, LTLf
  monitor compilation, and graph × DFA verification.
- `tests/`: unit, differential-semantics, regression, and CEGAR tests.
- `scripts/`: mining, reconstruction, audit, sensitivity, and evaluation code.
- `corpus/curated/`: authored controlled-evaluation workflows.
- `corpus/real_world/`: derived mined graphs, reconstructed references,
  provenance, labels, and analysis outputs.
- `corpus/annotations/`: independent human-validation materials.

See `LICENSE` for licensing terms.
