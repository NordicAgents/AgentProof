# Anonymized Review Artifact

Code-and-data artifact for the anonymous submission:

> **Auditing Static Analysis of Agent Workflows: Extraction Fidelity and
> Policy Applicability**

The artifact contains the analyzer, tests, derived corpora, reconstructed
reference graphs, LLM-assisted labels and justifications, audit scripts, and
the locked independent-human-validation protocol. It runs offline except for
the optional pinned re-mining step.

## Quick start

From the extracted `workflow_verifier/` directory:

```bash
python -m venv .venv
. .venv/bin/activate
pip install -e ".[dev]"
python -m pytest tests/ -q
PYTHONPATH=src python scripts/pruning_experiment.py
python scripts/fp_fn_decomposition.py
python scripts/human_agreement.py
```

The submitted revision passes 420 tests with one skipped test. The project has
no core runtime dependency; `pytest` is needed for the test suite.

## Key paper claims and artifacts

| Claim | Reproduction command | Output |
|---|---|---|
| 922-graph corpus census and audit summaries | `python scripts/reviewer_analyses.py` | `corpus/real_world/reviewer_analyses.json` |
| Matched extraction-fidelity comparison | `python scripts/matched_fidelity.py` | `corpus/real_world/matched_fidelity.json` |
| Finding attribution and reverse audit of misses | `PYTHONPATH=src python scripts/fp_fn_decomposition.py` | `corpus/real_world/fp_fn_decomposition.json` |
| HGP-1 source-level policy audit | `python scripts/human_gate_audit.py` | `corpus/real_world/human_gate_audit.json` |
| Path-sensitive monitor-selection demonstration | `PYTHONPATH=src python scripts/pruning_experiment.py` | `corpus/real_world/pruning_experiment.json` |
| Independent human agreement | `python scripts/human_agreement.py` | `corpus/annotations/human_agreement.json` |

The monitor checker returns `safe` only when the caller explicitly asserts that
the authored abstraction covers every relevant event. Exact source provenance
qualifies witnesses but does not establish event coverage. Mined graphs in this
study therefore receive no `safe` verdict.

## Human-validation status

The two-annotator protocol, locked samples, independent worksheets, and scoring
script are under `corpus/annotations/`. At submission-build time the worksheets
are blank, so the paper identifies independent human validation as pending.
After both annotators complete the worksheets, run:

```bash
python scripts/human_agreement.py
```

This produces human--human agreement, human--LLM agreement, graph-reconstruction
agreement, repository-cluster bootstrap intervals, and per-item scores.

## Anonymization and data handling

- Author names, organization identifiers, author-repository slugs, and local
  absolute paths are scrubbed in the archive.
- Third-party GitHub provenance is retained because it identifies the public
  data being audited, not the submitting authors.
- Third-party source snapshots are not redistributed. Derived graph
  abstractions, pinned repository/commit/path provenance, and optional
  `scripts/remine_pinned.py` are provided instead.
- The authors' own eight test-fixture files are pseudonymized with the
  `ANONYMIZED__SELFREPO` prefix and excluded from every reported denominator.

## Main contents

- `src/workflow_verifier/`: graph model, four framework extractors, checks, LTLf
  monitor compilation, and graph × DFA verification.
- `tests/`: unit, differential-semantics, regression, and CEGAR tests.
- `scripts/`: mining, reconstruction, audit, sensitivity, and evaluation code.
- `corpus/curated/`: authored controlled-evaluation workflows.
- `corpus/real_world/`: derived mined graphs, reconstructed references,
  provenance, labels, and analysis outputs.
- `corpus/annotations/`: independent human-validation materials.

See `LICENSE` for licensing terms.
