"""Framework semantic front-ends for WorkflowVerifier-CEGAR (plan §4.2).

A front-end turns a framework-specific agent program into an enriched
provenance-carrying :class:`~workflow_verifier.cegar.ir.MayMustGraph`, attaching tool
schemas and explicit :class:`~workflow_verifier.cegar.ir.UnsupportedFact` s for
constructs it cannot model precisely. The LangGraph front-end is the reference
implementation.
"""

from __future__ import annotations

from workflow_verifier.cegar.frontend.langgraph import (
    default_tool_schemas,
    extract_and_lift,
    lift,
)

__all__ = ["lift", "extract_and_lift", "default_tool_schemas"]
